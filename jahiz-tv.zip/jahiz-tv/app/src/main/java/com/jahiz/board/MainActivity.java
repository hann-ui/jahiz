package com.jahiz.board;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import fi.iki.elonen.NanoHTTPD;

public class MainActivity extends Activity {

    private static final int PORT = 8080;

    private SharedPreferences prefs;
    private BoardServer server;
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("jahiz", MODE_PRIVATE);
        String role = prefs.getString("role", null);
        if (role == null) showRolePicker();
        else applyRole(role);
    }

    // ---------------- role picker ----------------
    private void showRolePicker() {
        final boolean isTv = detectTv();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#16110D"));
        int pad = dp(24);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("جاهز");
        title.setTextColor(Color.parseColor("#F7AE2A"));
        title.setTextSize(42);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("اختر وضع هذا الجهاز");
        sub.setTextColor(Color.parseColor("#B39B82"));
        sub.setTextSize(16);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, dp(26));
        root.addView(sub);

        Button bDisplay = bigButton(isTv ? "شاشة العرض (هذا التلفزيون)" : "شاشة العرض (تلفزيون)", "#F7AE2A");
        bDisplay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setRole("display"); }
        });
        root.addView(bDisplay);

        Button bCtrl = bigButton("لوحة التحكم (موبايل)", "#F7AE2A");
        bCtrl.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setRole("controller"); }
        });
        root.addView(bCtrl);

        setContentView(root);
        if (isTv) bDisplay.requestFocus();
    }

    private boolean detectTv() {
        try {
            UiModeManager um = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
            return um != null && um.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION;
        } catch (Exception e) { return false; }
    }

    private Button bigButton(String text, String bg) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(18);
        b.setTextColor(Color.parseColor("#2A1A03"));
        b.setBackgroundColor(Color.parseColor(bg));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(300), dp(64));
        lp.topMargin = dp(12);
        b.setLayoutParams(lp);
        b.setFocusable(true);
        b.setFocusableInTouchMode(false);
        return b;
    }

    private void setRole(String role) {
        prefs.edit().putString("role", role).apply();
        applyRole(role);
    }

    private void applyRole(String role) {
        if ("display".equals(role)) {
            startServer();
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            showWeb("http://127.0.0.1:" + PORT + "/display");
        } else {
            String ip = prefs.getString("tvip", null);
            if (ip == null || ip.length() == 0) showConnect();
            else showWeb("http://" + ip + ":" + PORT + "/controller");
        }
    }

    // ---------------- connect screen (phone) ----------------
    private void showConnect() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#FBF6EE"));
        int pad = dp(24);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("ربط بالتلفزيون");
        title.setTextColor(Color.parseColor("#241C15"));
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("اكتب العنوان الظاهر أعلى شاشة العرض بالتلفزيون (مثال: 192.168.1.20). لازم الموبايل والتلفزيون على نفس شبكة الواي فاي.");
        help.setTextColor(Color.parseColor("#8A7A67"));
        help.setTextSize(15);
        help.setGravity(Gravity.CENTER);
        help.setPadding(0, dp(10), 0, dp(18));
        root.addView(help);

        final EditText ip = new EditText(this);
        ip.setHint("192.168.1.20");
        ip.setInputType(InputType.TYPE_CLASS_TEXT);
        ip.setText(prefs.getString("tvip", ""));
        ip.setTextColor(Color.parseColor("#241C15"));
        ip.setTextSize(20);
        ip.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ipp = new LinearLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT);
        ip.setLayoutParams(ipp);
        root.addView(ip);

        Button connect = bigButton("اتصال", "#EC9A0C");
        connect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String val = ip.getText().toString().trim();
                if (val.length() == 0) return;
                prefs.edit().putString("tvip", val).apply();
                showWeb("http://" + val + ":" + PORT + "/controller");
            }
        });
        root.addView(connect);

        setContentView(root);
    }

    // ---------------- server ----------------
    private void startServer() {
        if (server != null) return;
        try {
            server = new BoardServer(this, PORT);
            server.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
        } catch (Exception e) {
            server = null;
        }
    }

    // ---------------- webview host ----------------
    private void showWeb(String url) {
        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        try { ws.setMediaPlaybackRequiresUserGesture(false); } catch (Exception e) { /* ignore */ }
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String u) {
                v.loadUrl(u);
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(web);
        web.loadUrl(url);
    }

    public class Bridge {
        @JavascriptInterface
        public void changeServer() {
            runOnUiThread(new Runnable() { public void run() { showConnect(); } });
        }
        @JavascriptInterface
        public void resetRole() {
            runOnUiThread(new Runnable() {
                public void run() {
                    prefs.edit().remove("role").apply();
                    stopServer();
                    showRolePicker();
                }
            });
        }
    }

    private void stopServer() {
        if (server != null) { try { server.stop(); } catch (Exception e) { /* ignore */ } server = null; }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopServer();
    }
}
