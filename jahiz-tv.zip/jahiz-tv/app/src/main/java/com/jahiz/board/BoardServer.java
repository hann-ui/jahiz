package com.jahiz.board;

import android.content.Context;
import android.content.res.AssetManager;

import java.io.IOException;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.json.JSONArray;
import org.json.JSONObject;

import fi.iki.elonen.NanoHTTPD;

/**
 * Tiny LAN server that runs on the TV (display device). It holds the set of
 * "ready" tables in memory and serves the bundled web UI plus a small JSON API.
 * Phones on the same Wi-Fi connect to it — no internet required.
 */
public class BoardServer extends NanoHTTPD {

    private final Context ctx;
    private final ConcurrentHashMap<Integer, Long> ready = new ConcurrentHashMap<Integer, Long>();

    public BoardServer(Context c, int port) {
        super(port);
        this.ctx = c.getApplicationContext();
    }

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        try {
            if (uri != null && uri.startsWith("/api/")) return handleApi(uri, session);
            return serveAsset(uri);
        } catch (Exception e) {
            return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "error");
        }
    }

    private Response json(String s) {
        Response r = newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8", s);
        r.addHeader("Access-Control-Allow-Origin", "*");
        r.addHeader("Cache-Control", "no-store");
        return r;
    }

    private int paramInt(IHTTPSession s, String key, int def) {
        try {
            Map<String, List<String>> p = s.getParameters();
            if (p != null && p.containsKey(key)) {
                List<String> v = p.get(key);
                if (v != null && v.size() > 0) return Integer.parseInt(v.get(0).trim());
            }
        } catch (Exception e) { /* ignore */ }
        return def;
    }

    private Response handleApi(String uri, IHTTPSession session) throws Exception {
        if (uri.equals("/api/state")) {
            JSONObject o = new JSONObject();
            o.put("now", System.currentTimeMillis());
            JSONArray arr = new JSONArray();
            for (Map.Entry<Integer, Long> e : ready.entrySet()) {
                JSONObject t = new JSONObject();
                t.put("t", e.getKey());
                t.put("at", e.getValue());
                arr.put(t);
            }
            o.put("tables", arr);
            return json(o.toString());
        }
        if (uri.equals("/api/ready")) {
            int t = paramInt(session, "t", -1);
            if (t > 0 && !ready.containsKey(t)) ready.put(t, System.currentTimeMillis());
            return json("{\"ok\":true}");
        }
        if (uri.equals("/api/clear")) {
            int t = paramInt(session, "t", -1);
            if (t > 0) ready.remove(t);
            return json("{\"ok\":true}");
        }
        if (uri.equals("/api/clearall")) {
            ready.clear();
            return json("{\"ok\":true}");
        }
        if (uri.equals("/api/info")) {
            JSONObject o = new JSONObject();
            o.put("ip", getLocalIp());
            o.put("port", getListeningPort());
            return json(o.toString());
        }
        return json("{\"ok\":false}");
    }

    private Response serveAsset(String uri) {
        String path;
        if (uri == null || uri.equals("/") || uri.equals("/display")) path = "web/display.html";
        else if (uri.equals("/controller")) path = "web/controller.html";
        else path = "web" + uri;
        try {
            AssetManager am = ctx.getAssets();
            InputStream is = am.open(path);
            Response r = newChunkedResponse(Response.Status.OK, mime(path), is);
            r.addHeader("Access-Control-Allow-Origin", "*");
            r.addHeader("Cache-Control", "no-store");
            return r;
        } catch (IOException e) {
            return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "not found");
        }
    }

    private String mime(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html")) return "text/html; charset=utf-8";
        if (p.endsWith(".css")) return "text/css; charset=utf-8";
        if (p.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (p.endsWith(".woff2")) return "font/woff2";
        if (p.endsWith(".woff")) return "font/woff";
        if (p.endsWith(".wav")) return "audio/wav";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".svg")) return "image/svg+xml";
        return "application/octet-stream";
    }

    /** Best-effort site-local IPv4 (e.g. 192.168.x.x) to show for pairing. */
    public static String getLocalIp() {
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            while (ifaces.hasMoreElements()) {
                NetworkInterface ni = ifaces.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress a = addrs.nextElement();
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }
        return "غير متاح";
    }
}
