/* جاهز — shared client logic for display + controller.
   ES5 + XMLHttpRequest for maximum WebView compatibility (old Android TV). */
(function(){
  var MODE = window.MODE || 'display';
  var TCOUNT = window.TABLE_COUNT || 50;

  var serverNow = 0, lastSync = 0;
  var connected = null, primed = false;
  var tables = {};      // "5": readyAtMs
  var prevSet = {};     // for new-arrival detection (display)
  var cellsBuilt = false;
  var lastBoardSig = null;

  var ding = null;
  try { ding = new Audio('ding.wav'); ding.preload = 'auto'; } catch (e) {}

  function $(id){ return document.getElementById(id); }

  function xhr(method, url, cb){
    try{
      var r = new XMLHttpRequest();
      r.open(method, url, true);
      r.timeout = 4000;
      r.onreadystatechange = function(){
        if (r.readyState === 4){
          if (r.status >= 200 && r.status < 300) cb(null, r.responseText);
          else cb(true);
        }
      };
      r.ontimeout = function(){ cb(true); };
      r.onerror = function(){ cb(true); };
      r.send();
    } catch (e){ cb(true); }
  }

  function setConnected(v){
    if (connected === v) return;
    connected = v;
    if (MODE === 'controller'){ var c = $('cConn'); if (c) c.hidden = v; }
  }

  function now(){ return new Date().getTime(); }
  function nowServer(){ return serverNow + (now() - lastSync); }

  function fmt(ms){
    var s = Math.floor(ms / 1000); if (s < 0) s = 0;
    var m = Math.floor(s / 60); s = s % 60;
    return m + ':' + (s < 10 ? '0' : '') + s;
  }

  function inArray(a, v){ for (var i = 0; i < a.length; i++) if (a[i] === v) return true; return false; }

  function playDing(){
    if (!ding) return;
    try { ding.currentTime = 0; var p = ding.play(); if (p && p['catch']) p['catch'](function(){}); } catch (e){}
  }
  function flash(){
    var f = $('flash'); if (!f) return;
    f.className = ''; void f.offsetWidth; f.className = 'on';
  }

  function fetchState(){
    xhr('GET', '/api/state?ts=' + now(), function(err, txt){
      if (err){ setConnected(false); return; }
      setConnected(true);
      var data; try { data = JSON.parse(txt); } catch (e){ return; }
      serverNow = data.now || 0; lastSync = now();
      var nt = {}, arr = data.tables || [], i;
      for (i = 0; i < arr.length; i++) nt[String(arr[i].t)] = arr[i].at;

      if (MODE === 'display'){
        var isNew = [], k;
        for (k in nt){ if (nt.hasOwnProperty(k) && !prevSet.hasOwnProperty(k)) isNew.push(k); }
        tables = nt;
        render(isNew);
        if (primed && isNew.length){ playDing(); flash(); }
        prevSet = {}; for (k in nt){ if (nt.hasOwnProperty(k)) prevSet[k] = nt[k]; }
        primed = true;
      } else {
        tables = nt; render([]);
      }
      tick(); // refresh timers immediately after each update
    });
  }

  function countTables(){ var n = 0, k; for (k in tables){ if (tables.hasOwnProperty(k)) n++; } return n; }

  function sortedTables(){
    var a = [], k;
    for (k in tables){ if (tables.hasOwnProperty(k)) a.push({ t: parseInt(k, 10), at: tables[k] }); }
    a.sort(function(x, y){ return x.at - y.at; });
    return a;
  }

  function render(isNew){
    if (MODE === 'display') renderDisplay(isNew); else renderController();
    var cnt = countTables();
    var cc = $(MODE === 'display' ? 'dCount' : 'cCount'); if (cc) cc.innerHTML = cnt;
    if (MODE === 'controller'){ var cl = $('cClear'); if (cl) cl.disabled = (cnt === 0); }
  }

  function renderDisplay(isNew){
    var board = $('board'), empty = $('empty'); if (!board) return;
    var arr = sortedTables();
    if (empty) empty.style.display = arr.length ? 'none' : '';
    // Only rebuild the DOM when the set actually changes (timers update via tick()).
    var sig = '';
    for (var s = 0; s < arr.length; s++) sig += arr[s].t + ':' + arr[s].at + ',';
    if (sig === lastBoardSig) return;
    lastBoardSig = sig;
    var html = '';
    for (var i = 0; i < arr.length; i++){
      var it = arr[i];
      var isN = isNew && inArray(isNew, String(it.t));
      html += '<div class="card' + (isN ? ' isnew' : '') + '">' +
        '<div class="c-top"><span class="c-tbl">طاولة رقم</span>' +
        '<span class="c-timer" data-at="' + it.at + '">0:00</span></div>' +
        '<div class="c-num">' + it.t + '</div>' +
        '<div class="c-ready">🔔 الطلب جاهز</div>' +
      '</div>';
    }
    board.innerHTML = html;
  }

  function renderController(){
    var grid = $('grid'); if (!grid) return;
    if (!cellsBuilt){
      var h = '', n;
      for (n = 1; n <= TCOUNT; n++){
        h += '<button class="cell" data-t="' + n + '">' +
             '<span class="cell-n">' + n + '</span>' +
             '<span class="cell-l">طاولة</span>' +
             '<span class="cell-t" data-at="">0:00</span></button>';
      }
      grid.innerHTML = h; cellsBuilt = true;
      grid.onclick = function(e){
        var el = e.target || e.srcElement;
        while (el && el !== grid && !(el.getAttribute && el.getAttribute('data-t'))) el = el.parentNode;
        if (el && el.getAttribute && el.getAttribute('data-t')) toggle(parseInt(el.getAttribute('data-t'), 10));
      };
    }
    var cells = grid.getElementsByClassName('cell');
    for (var i = 0; i < cells.length; i++){
      var c = cells[i], key = c.getAttribute('data-t');
      var on = tables.hasOwnProperty(key);
      var tEl = c.getElementsByClassName('cell-t')[0];
      if (on){ c.className = 'cell on'; if (tEl) tEl.setAttribute('data-at', tables[key]); }
      else { c.className = 'cell'; if (tEl) tEl.setAttribute('data-at', ''); }
    }
  }

  function toggle(n){
    var key = String(n);
    var on = tables.hasOwnProperty(key);
    if (on) delete tables[key]; else tables[key] = nowServer();  // optimistic
    render([]);
    xhr('POST', (on ? '/api/clear' : '/api/ready') + '?t=' + n + '&ts=' + now(), function(err){
      if (err) setConnected(false); else { setConnected(true); fetchState(); }
    });
  }

  function clearAll(){
    tables = {}; render([]);
    xhr('POST', '/api/clearall?ts=' + now(), function(err){ if (!err) fetchState(); });
  }

  function tick(){
    var base = nowServer();
    var nodes = document.querySelectorAll ? document.querySelectorAll('[data-at]') : [];
    for (var i = 0; i < nodes.length; i++){
      var at = nodes[i].getAttribute('data-at');
      if (!at) continue;
      nodes[i].innerHTML = fmt(base - parseInt(at, 10));
    }
    var dc = $('dClock');
    if (dc){ var d = new Date(), h = d.getHours(), m = d.getMinutes();
      dc.innerHTML = (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m; }
  }

  function loadInfo(){
    xhr('GET', '/api/info?ts=' + now(), function(err, txt){
      if (err) return;
      var d; try { d = JSON.parse(txt); } catch (e){ return; }
      var ipEl = $('dIp');
      if (ipEl && d.ip) ipEl.innerHTML = 'لربط الموبايل: ' + d.ip + ':' + d.port;
    });
  }

  function changeServer(){ if (window.AndroidBridge && AndroidBridge.changeServer) AndroidBridge.changeServer(); }
  function resetRole(){ if (window.AndroidBridge && AndroidBridge.resetRole) AndroidBridge.resetRole(); }

  function wire(){
    if (MODE === 'controller'){
      var cl = $('cClear'); if (cl) cl.onclick = clearAll;
      var b = $('cChange'); if (b) b.onclick = changeServer;
      var g = $('cGear'); if (g) g.onclick = changeServer;
    } else {
      var r = $('dReset'); if (r) r.onclick = resetRole;
      loadInfo();
      setInterval(loadInfo, 15000);
    }
  }

  wire();
  fetchState();
  setInterval(fetchState, MODE === 'display' ? 900 : 1300);
  setInterval(tick, 1000);
  tick();
})();
