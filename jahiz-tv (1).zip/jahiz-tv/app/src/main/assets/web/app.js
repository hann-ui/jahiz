/* جاهز — shared client logic for display + controller (tables & delivery modes).
   ES5 + XMLHttpRequest for maximum WebView compatibility (old Android TV). */
(function(){
  var PAGE = window.MODE || 'display';        // 'display' | 'controller'
  var TCOUNT = window.TABLE_COUNT || 50;

  var serverNow = 0, lastSync = 0;
  var connected = null, primed = false;
  var tables = {};          // "5": readyAtMs
  var prevSet = {};         // new-arrival detection (display)
  var pendingNew = [];
  var lastBoardSig = null;
  var curMode = 'tables';   // restaurant mode: 'tables' | 'delivery'
  var appliedMode = null;
  var gridBuilt = false, keypadBuilt = false;
  var dlvBuffer = '';

  var ding = null;
  try { ding = new Audio('ding.wav'); ding.preload = 'auto'; } catch (e) {}

  function $(id){ return document.getElementById(id); }

  function xhr(method, url, cb){
    try{
      var r = new XMLHttpRequest();
      r.open(method, url, true);
      r.timeout = 4000;
      r.onreadystatechange = function(){
        if (r.readyState === 4){
          if (r.status >= 200 && r.status < 300) cb(null, r.responseText);
          else cb(true);
        }
      };
      r.ontimeout = function(){ cb(true); };
      r.onerror = function(){ cb(true); };
      r.send();
    } catch (e){ cb(true); }
  }

  function setConnected(v){
    if (connected === v) return;
    connected = v;
    if (PAGE === 'controller'){ var c = $('cConn'); if (c) c.hidden = v; }
  }

  function now(){ return new Date().getTime(); }
  function nowServer(){ return serverNow + (now() - lastSync); }
  function fmt(ms){
    var s = Math.floor(ms/1000); if (s < 0) s = 0;
    var m = Math.floor(s/60); s = s%60;
    return m + ':' + (s<10?'0':'') + s;
  }
  function inArray(a,v){ for (var i=0;i<a.length;i++) if (a[i]===v) return true; return false; }
  function countTables(){ var n=0,k; for (k in tables){ if (tables.hasOwnProperty(k)) n++; } return n; }
  function sortedTables(){
    var a=[],k;
    for (k in tables){ if (tables.hasOwnProperty(k)) a.push({t:parseInt(k,10),at:tables[k]}); }
    a.sort(function(x,y){ return x.at-y.at; });
    return a;
  }

  function playDing(){
    if (!ding) return;
    try { ding.currentTime = 0; var p = ding.play(); if (p && p['catch']) p['catch'](function(){}); } catch (e){}
  }
  function flash(){ var f=$('flash'); if(!f) return; f.className=''; void f.offsetWidth; f.className='on'; }

  /* ---------------- state polling ---------------- */
  function fetchState(){
    xhr('GET', '/api/state?ts=' + now(), function(err, txt){
      if (err){ setConnected(false); return; }
      setConnected(true);
      var data; try { data = JSON.parse(txt); } catch (e){ return; }
      serverNow = data.now || 0; lastSync = now();
      curMode = (data.mode === 'delivery') ? 'delivery' : 'tables';
      var nt = {}, arr = data.tables || [], i;
      for (i=0;i<arr.length;i++) nt[String(arr[i].t)] = arr[i].at;

      if (PAGE === 'display'){
        var isNew = [], k;
        for (k in nt){ if (nt.hasOwnProperty(k) && !prevSet.hasOwnProperty(k)) isNew.push(k); }
        tables = nt; pendingNew = isNew;
        render();
        if (primed && isNew.length){ playDing(); flash(); }
        prevSet = {}; for (k in nt){ if (nt.hasOwnProperty(k)) prevSet[k]=nt[k]; }
        primed = true;
      } else {
        tables = nt; render();
      }
      tick();
    });
  }

  function render(){
    if (PAGE === 'display') renderDisplay(); else renderController();
    var cnt = countTables();
    var cc = $(PAGE === 'display' ? 'dCount' : 'cCount'); if (cc) cc.innerHTML = cnt;
    if (PAGE === 'controller'){ var cl = $('cClear'); if (cl) cl.disabled = (cnt === 0); }
  }

  /* ---------------- display board ---------------- */
  function renderDisplay(){
    var board = $('board'), empty = $('empty'); if (!board) return;
    var arr = sortedTables();
    if (empty) empty.style.display = arr.length ? 'none' : '';
    var label = (curMode === 'delivery') ? 'رقم الوصل' : 'طاولة رقم';
    var sig = curMode + '|';
    for (var s=0;s<arr.length;s++) sig += arr[s].t + ':' + arr[s].at + ',';
    if (sig === lastBoardSig) return;
    lastBoardSig = sig;
    var html = '';
    for (var i=0;i<arr.length;i++){
      var it = arr[i];
      var isN = inArray(pendingNew, String(it.t));
      html += '<div class="card' + (isN?' isnew':'') + '">' +
        '<div class="c-top"><span class="c-tbl">' + label + '</span>' +
        '<span class="c-timer" data-at="' + it.at + '">0:00</span></div>' +
        '<div class="c-num">' + it.t + '</div>' +
        '<div class="c-ready">&#128276; الطلب جاهز</div>' +
      '</div>';
    }
    board.innerHTML = html;
  }

  /* ---------------- controller ---------------- */
  function renderController(){
    // reflect mode toggle
    var mt = $('mTables'), md = $('mDelivery');
    if (mt) mt.className = 'mbtn' + (curMode==='tables' ? ' active' : '');
    if (md) md.className = 'mbtn' + (curMode==='delivery' ? ' active' : '');
    // switch views when mode changes
    if (appliedMode !== curMode){
      appliedMode = curMode;
      var tv = $('tablesView'), dv = $('deliveryView');
      if (tv) tv.hidden = (curMode !== 'tables');
      if (dv) dv.hidden = (curMode !== 'delivery');
    }
    if (curMode === 'tables') renderTables(); else renderDelivery();
  }

  function renderTables(){
    var grid = $('grid'); if (!grid) return;
    if (!gridBuilt){
      var h = '', n;
      for (n=1;n<=TCOUNT;n++){
        h += '<button class="cell" data-t="' + n + '">' +
             '<span class="cell-n">' + n + '</span>' +
             '<span class="cell-l">طاولة</span>' +
             '<span class="cell-t" data-at="">0:00</span></button>';
      }
      grid.innerHTML = h; gridBuilt = true;
      grid.onclick = function(e){
        var el = e.target || e.srcElement;
        while (el && el !== grid && !(el.getAttribute && el.getAttribute('data-t'))) el = el.parentNode;
        if (el && el.getAttribute && el.getAttribute('data-t')) toggleTable(parseInt(el.getAttribute('data-t'),10));
      };
    }
    var cells = grid.getElementsByClassName('cell');
    for (var i=0;i<cells.length;i++){
      var c = cells[i], key = c.getAttribute('data-t');
      var on = tables.hasOwnProperty(key);
      var tEl = c.getElementsByClassName('cell-t')[0];
      if (on){ c.className='cell on'; if (tEl) tEl.setAttribute('data-at', tables[key]); }
      else { c.className='cell'; if (tEl) tEl.setAttribute('data-at',''); }
    }
  }

  function renderDelivery(){
    buildKeypad();
    var scr = $('dlvScreen'); if (scr) scr.innerHTML = dlvBuffer.length ? dlvBuffer : '&mdash;';
    var list = $('activeList'); if (!list) return;
    var arr = sortedTables();
    if (!arr.length){ list.innerHTML = '<div class="active-empty">ماكو طلبات جاهزة الآن.</div>'; return; }
    var html = '';
    for (var i=0;i<arr.length;i++){
      html += '<button class="active-chip" data-t="' + arr[i].t + '">' +
        '<span class="an">' + arr[i].t + '</span>' +
        '<span class="at" data-at="' + arr[i].at + '">0:00</span></button>';
    }
    list.innerHTML = html;
  }

  function buildKeypad(){
    if (keypadBuilt) return;
    var kp = $('keypad'); if (!kp) return;
    var keys = ['1','2','3','4','5','6','7','8','9','C','0','back'];
    var h = '';
    for (var i=0;i<keys.length;i++){
      var k = keys[i];
      if (k === 'back') h += '<button class="key act" data-k="back">&#9003;</button>';
      else if (k === 'C') h += '<button class="key act" data-k="C">C</button>';
      else h += '<button class="key" data-k="' + k + '">' + k + '</button>';
    }
    kp.innerHTML = h; keypadBuilt = true;
    kp.onclick = function(e){
      var el = e.target || e.srcElement;
      while (el && el !== kp && !(el.getAttribute && el.getAttribute('data-k'))) el = el.parentNode;
      if (!el || !el.getAttribute) return;
      var k = el.getAttribute('data-k');
      if (k === 'back') dlvBuffer = dlvBuffer.slice(0, -1);
      else if (k === 'C') dlvBuffer = '';
      else if (dlvBuffer.length < 6) dlvBuffer += k;
      var scr = $('dlvScreen'); if (scr) scr.innerHTML = dlvBuffer.length ? dlvBuffer : '&mdash;';
    };
    var send = $('dlvSend');
    if (send) send.onclick = function(){
      var n = parseInt(dlvBuffer, 10);
      if (!n || n <= 0){ return; }
      markReady(n);
      dlvBuffer = '';
      var scr = $('dlvScreen'); if (scr) scr.innerHTML = '&mdash;';
    };
    var list = $('activeList');
    if (list) list.onclick = function(e){
      var el = e.target || e.srcElement;
      while (el && el !== list && !(el.getAttribute && el.getAttribute('data-t'))) el = el.parentNode;
      if (el && el.getAttribute && el.getAttribute('data-t')) clearNum(parseInt(el.getAttribute('data-t'),10));
    };
  }

  /* ---------------- actions ---------------- */
  function markReady(n){
    tables[String(n)] = nowServer(); render();
    xhr('POST', '/api/ready?t=' + n + '&ts=' + now(), function(err){
      if (err) setConnected(false); else { setConnected(true); fetchState(); }
    });
  }
  function clearNum(n){
    delete tables[String(n)]; render();
    xhr('POST', '/api/clear?t=' + n + '&ts=' + now(), function(err){ if (!err) fetchState(); });
  }
  function toggleTable(n){
    if (tables.hasOwnProperty(String(n))) clearNum(n); else markReady(n);
  }
  function clearAll(){
    tables = {}; render();
    xhr('POST', '/api/clearall?ts=' + now(), function(err){ if (!err) fetchState(); });
  }
  function setMode(m){
    if (m === curMode) return;
    curMode = m; tables = {}; dlvBuffer = ''; render();
    xhr('POST', '/api/mode?m=' + m + '&ts=' + now(), function(err){ if (!err) fetchState(); });
  }

  /* ---------------- timers + clock ---------------- */
  function tick(){
    var base = nowServer();
    var nodes = document.querySelectorAll ? document.querySelectorAll('[data-at]') : [];
    for (var i=0;i<nodes.length;i++){
      var at = nodes[i].getAttribute('data-at');
      if (!at) continue;
      nodes[i].innerHTML = fmt(base - parseInt(at,10));
    }
    var dc = $('dClock');
    if (dc){ var d=new Date(), h=d.getHours(), m=d.getMinutes();
      dc.innerHTML = (h<10?'0':'')+h+':'+(m<10?'0':'')+m; }
  }

  function loadInfo(){
    xhr('GET', '/api/info?ts=' + now(), function(err, txt){
      if (err) return;
      var d; try { d = JSON.parse(txt); } catch (e){ return; }
      var ipEl = $('dIp');
      if (ipEl && d.ip) ipEl.innerHTML = 'لربط الموبايل: ' + d.ip + ':' + d.port;
    });
  }

  function changeServer(){ if (window.AndroidBridge && AndroidBridge.changeServer) AndroidBridge.changeServer(); }
  function resetRole(){ if (window.AndroidBridge && AndroidBridge.resetRole) AndroidBridge.resetRole(); }

  function wire(){
    if (PAGE === 'controller'){
      var cl = $('cClear'); if (cl) cl.onclick = clearAll;
      var chg = $('cChange'); if (chg) chg.onclick = changeServer;
      var g = $('cGear'); if (g) g.onclick = changeServer;
      var mt = $('mTables'); if (mt) mt.onclick = function(){ setMode('tables'); };
      var md = $('mDelivery'); if (md) md.onclick = function(){ setMode('delivery'); };
    } else {
      var r = $('dReset'); if (r) r.onclick = resetRole;
      loadInfo();
      setInterval(loadInfo, 15000);
    }
  }

  wire();
  fetchState();
  setInterval(fetchState, PAGE === 'display' ? 900 : 1300);
  setInterval(tick, 1000);
  tick();
})();
